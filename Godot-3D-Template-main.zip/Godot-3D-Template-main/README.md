# Godot-3D-Template

Godot Template for 3D Games

Includes Keyboard mappings and Global.gd
